<footer style="text-align:center; padding:20px; background:#eee;">
    <p>&copy; 2025 Công ty ABC. All rights reserved.</p>
</footer>