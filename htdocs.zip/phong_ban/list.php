<?php
$content_view = __DIR__ . '/list_content.php';
include '../layout.php';
